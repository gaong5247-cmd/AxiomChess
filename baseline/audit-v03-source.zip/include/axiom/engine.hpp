#pragma once
#include "axiom/chess.hpp"
#include "axiom/evaluation.hpp"
#include <atomic>
#include <chrono>
#include <functional>
#include <map>
#include <memory>
#include <mutex>
#include <unordered_map>

namespace axiom {
constexpr int MateScore=30000, MateThreshold=29000, Infinity=32000, MaxPly=120;
int piece_value(int piece);
struct Evaluation { int total=0; double phase=0; std::map<std::string,int> terms; };
Evaluation evaluate(const Board& b);
int see(Board& b,Move m);
std::vector<std::string> tactical_labels(Board& b,Move m);
enum class Status { ExactTablebase, ProvenMate, ProvenForcedResult, SearchResult, HeuristicEvaluation };
std::string status_name(Status s);
enum class Bound { Exact, Lower, Upper, Estimate };
std::string bound_name(Bound b);
struct Features {
    bool correction=false, continuation=false, capture_history=false, countermove=false;
    bool singular=false, verified_null=false, probcut=false, dynamic_lmr=false;
    bool history_pruning=false, see_pruning=false, mate_distance=false, iid=false;
    bool tt_policy=false, time_management=false;
    bool strategic_eval=false, king_safety=false, search_safety=false, pawn_cache=true;
    bool set(const std::string& name,bool enabled);
    void all(bool enabled);
    void middlegame();
    std::string names() const;
};
struct SearchStats {
    std::uint64_t correction_updates=0, continuation_updates=0, capture_updates=0;
    std::uint64_t tt_hits=0, null_attempts=0, null_verifications=0, null_rejections=0;
    std::uint64_t singular_tests=0, singular_extensions=0, probcut_attempts=0, probcut_cutoffs=0;
    std::uint64_t lmr_reductions=0, lmr_researches=0, history_prunes=0, see_prunes=0;
    std::uint64_t mate_distance_cutoffs=0, iid_searches=0, bestmove_changes=0;
    int root_correction=0, threads=1;
    std::uint64_t safety_protected=0,pawn_cache_hits=0,pawn_cache_misses=0;
};
struct TTEntry {
    std::uint64_t key=0;
    std::string context;
    int depth=-1,score=0;
    Bound bound=Bound::Estimate;
    Move move;
    bool pv=false;
    unsigned generation=0;
};
class TranspositionTable {
public:
    explicit TranspositionTable(std::size_t mb=32);
    std::optional<TTEntry> probe(std::uint64_t key,const std::string& context) const;
    void store(TTEntry entry,bool policy);
    void clear();
    void new_search() { ++generation_; }
    unsigned generation() const { return generation_; }
    std::size_t buckets() const { return buckets_.size(); }
private:
    struct Bucket { std::array<TTEntry,4> entries; };
    std::vector<Bucket> buckets_;
    mutable std::array<std::mutex,64> locks_;
    unsigned generation_=0;
};
struct SearchTrace { Move move; int piece=0,static_eval=Infinity; };
class Feedback {
public:
    Feedback();
    void clear();
    int correction(const Board& b,int previous) const;
    void update_correction(const Board& b,int previous,int error,int depth);
    int continuation(int previous,int current,int distance) const;
    void update_continuation(int previous,int current,int distance,int bonus);
    int capture_score(int piece,int to,int victim) const;
    void update_capture(int piece,int to,int victim,int bonus);
    Move counter(int previous) const;
    void set_counter(int previous,Move move);
    static int token(int piece,int to);
    static void update(std::int16_t& value,int bonus,int limit=16000);
private:
    std::array<std::vector<std::int16_t>,5> corrections_;
    std::array<std::vector<std::int16_t>,4> continuations_;
    std::vector<std::int16_t> captures_;
    std::array<Move,769> counters_{};
    std::array<std::size_t,5> correction_keys(const Board& b,int previous) const;
};
struct ProofNode {
    // Attacker: one selected edge. Defender: every legal edge.
    std::vector<std::pair<Move,std::shared_ptr<ProofNode>>> edges;
    int distance=0;
};
struct MateProof {
    bool proven=false, exhausted=false;
    int attacker=White, distance=-1;
    std::uint64_t nodes=0;
    std::shared_ptr<ProofNode> certificate;
};
class MateSolver {
public:
    MateProof solve(Board board,int attacker,int max_plies,std::uint64_t budget,
                    std::atomic_bool* stop=nullptr,
                    std::chrono::steady_clock::time_point deadline=std::chrono::steady_clock::time_point::max());
    static bool verify(Board board,int attacker,const std::shared_ptr<ProofNode>& certificate);
private:
    std::uint64_t nodes_=0, budget_=0;
    bool exhausted_=false;
    int attacker_=White;
    std::atomic_bool* stop_=nullptr;
    std::chrono::steady_clock::time_point deadline_;
    std::shared_ptr<ProofNode> visit(Board& b,int remaining);
};
struct TBResult { int wdl=0, dtz=0; bool exact=false; Move best; std::string reason; };
class Tablebase {
public:
    bool open(const std::string& path);
    std::optional<TBResult> probe(Board& b) const;
    bool enabled() const { return ready_; }
    static bool compiled();
private:
    bool ready_=false;
};
struct Limits {
    int depth=6, milliseconds=1000, mate_plies=5;
    std::uint64_t nodes=0, proof_nodes=15000;
    bool verify=false, selective=true;
    Features features;
    int threads=1, soft_milliseconds=0;
    bool diagnostics=false;
};
struct MoveResult {
    Move move; int score=0, depth=0, mate_distance=-1;
    Status status=Status::HeuristicEvaluation;
    Bound bound=Bound::Estimate;
    std::uint64_t nodes=0;
    std::vector<Move> pv;
    std::vector<std::string> tactics;
    bool tactical_verified=false;
    int verification_depth=0, verification_score=0;
    Move strongest_reply;
    std::optional<TBResult> tablebase;
};
struct SearchResult {
    Move best;
    Status status=Status::HeuristicEvaluation;
    std::string outcome="UNKNOWN";
    int depth=0, score=0;
    std::uint64_t nodes=0, proof_nodes=0;
    long long elapsed_ms=0;
    std::vector<MoveResult> moves;
    Evaluation evaluation;
    bool claim_draw=false, verification_completed=false, certificate_verified=false;
    std::string verification_detail;
    std::optional<TBResult> tablebase;
    SearchStats stats;
    std::string features;
};
class Search {
public:
    explicit Search(std::size_t hash_mb=32);
    SearchResult run(Board b,Limits limits,std::atomic_bool& stop,
                     const std::function<void(const SearchResult&)>& info={});
    Tablebase tablebase;
    void clear();
private:
    std::shared_ptr<TranspositionTable> tt_;
    std::unique_ptr<Feedback> feedback_;
    std::unique_ptr<PawnCache> pawn_cache_;
    std::array<SearchTrace,MaxPly> trace_{};
    SearchStats stats_;
    std::string previous_policy_;
    std::atomic_bool* local_stop_=nullptr;
    std::atomic<std::uint64_t>* shared_nodes_=nullptr;
    int worker_id_=0;
    Move killers_[MaxPly][2]{};
    int history_[2][128][128]{};
    Limits limits_;
    std::atomic_bool* stop_=nullptr;
    std::chrono::steady_clock::time_point start_,deadline_;
    std::uint64_t nodes_=0;
    void tick();
    int negamax(Board& b,int depth,int alpha,int beta,int ply,bool pv,bool null_allowed,std::vector<Move>& line,bool synthetic=false,Move excluded={},bool auxiliary=false,int extensions=0,bool cut_node=false);
    int quiescence(Board& b,int alpha,int beta,int ply,int qply,bool synthetic=false,bool clean=false);
    void order(Board& b,std::vector<Move>& moves,Move tt,int ply);
    std::vector<MoveResult> root(Board& b,int depth,int alpha,int beta,bool independent=false);
    SearchResult run_single(Board b,Limits limits,std::atomic_bool& stop,const std::function<void(const SearchResult&)>& info);
    int previous_token(int ply,int distance=1) const;
    int history_score(const Board& b,Move m,int ply) const;
    int corrected_eval(const Board& b,int raw,int ply) const;
    int static_evaluation(const Board& b);
};
std::string json(const SearchResult& result,const Board& b);
}
