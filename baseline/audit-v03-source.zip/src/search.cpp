#include "axiom/engine.hpp"
#include <algorithm>
#include <cmath>
#include <sstream>
#include <stdexcept>
#include <thread>

namespace axiom {
namespace {
struct Interrupted {};
struct Applied { Board& b; Undo undo; Applied(Board& board,Move m):b(board),undo(m?b.push(m):b.push_null()) {} ~Applied(){b.pop(undo);} };
int to_tt(int s,int ply) { return s>MateThreshold?s+ply:s<-MateThreshold?s-ply:s; }
int from_tt(int s,int ply) { return s>MateThreshold?s-ply:s<-MateThreshold?s+ply:s; }
bool null_material(const Board& b) {
    int count=0, nonpawns=0;
    for(int s=0;s<128;++s) if(valid(s) && color(b.squares[s])==b.side) {
        int pt=std::abs(b.squares[s]); if(pt!=Pawn && pt!=King) { nonpawns+=piece_value(pt); ++count; }
    }
    return count>=2 && nonpawns>=850 && b.piece_count()>10 && b.halfmove<80;
}
std::string escaped(const std::string& s) { std::string out="\""; for(unsigned char c:s) {
    if(c=='"' || c=='\\') { out+='\\'; out+=static_cast<char>(c); } else if(c=='\n') out+="\\n"; else if(c>=32) out+=static_cast<char>(c);
    } return out+'"'; }
}
Search::Search(std::size_t mb):tt_(std::make_shared<TranspositionTable>(mb)),feedback_(std::make_unique<Feedback>()),pawn_cache_(std::make_unique<PawnCache>()) {}
void Search::clear() { tt_->clear(); feedback_->clear(); pawn_cache_->clear(); for(auto& row:killers_) for(auto& m:row) m=Move{}; for(auto& side:history_) for(auto& from:side) for(auto& to:from) to=0; trace_.fill(SearchTrace{}); }
int Search::static_evaluation(const Board& b) { return evaluate_score(b,limits_.features.strategic_eval,limits_.features.king_safety,limits_.features.pawn_cache?pawn_cache_.get():nullptr); }
void Search::tick() {
    if(stop_->load() || (local_stop_ && local_stop_->load()) || std::chrono::steady_clock::now()>=deadline_) throw Interrupted{};
    if(shared_nodes_) {
        auto previous=shared_nodes_->fetch_add(1);
        if(limits_.nodes && previous>=limits_.nodes) { shared_nodes_->fetch_sub(1); throw Interrupted{}; }
    } else if(limits_.nodes && nodes_>=limits_.nodes) throw Interrupted{};
    ++nodes_;
}
int Search::previous_token(int ply,int distance) const { if(ply<distance) return 0; const auto& prev=trace_[ply-distance]; return Feedback::token(prev.piece,prev.move.to); }
int Search::history_score(const Board& b,Move m,int ply) const {
    int score=history_[b.side==White?0:1][m.from][m.to];
    if(limits_.features.continuation) { int current=Feedback::token(b.squares[m.from],m.to),i=0;
        for(int distance:{1,2,4,6}) score+=feedback_->continuation(previous_token(ply,distance),current,i++)/2;
    } return score;
}
int Search::corrected_eval(const Board& b,int raw,int ply) const {
    int value=raw+(limits_.features.correction?feedback_->correction(b,previous_token(ply)):0);
    return std::clamp(value,-MateThreshold+1,MateThreshold-1);
}
void Search::order(Board& b,std::vector<Move>& moves,Move tt,int ply) {
    std::vector<std::pair<int,Move>> ranked; ranked.reserve(moves.size());
    for(auto m:moves) {
        int score=history_score(b,m,ply);
        if(m==tt) score+=2000000;
        else if(b.capture(m)) { int exchange=see(b,m); score+=(exchange>=0?1000000:-100000)+10*piece_value(b.squares[m.to])-piece_value(b.squares[m.from])+exchange;
            if(limits_.features.capture_history) score+=feedback_->capture_score(b.squares[m.from],m.to,b.squares[m.to]?std::abs(b.squares[m.to]):Pawn); }
        if(m.promotion) score+=800000+piece_value(m.promotion);
        if(b.gives_check(m)) score+=300000;
        if(ply<MaxPly && (m==killers_[ply][0] || m==killers_[ply][1])) score+=200000;
        if(limits_.features.countermove && m==feedback_->counter(previous_token(ply))) score+=150000;
        if(worker_id_ && m!=tt) score+=(m.from*37+m.to*17+worker_id_*31)%71;
        ranked.push_back({score,m});
    }
    std::stable_sort(ranked.begin(),ranked.end(),[](const auto& a,const auto& c){return a.first>c.first;});
    for(std::size_t i=0;i<moves.size();++i) moves[i]=ranked[i].second;
}
int Search::quiescence(Board& b,int alpha,int beta,int ply,int qply,bool synthetic,bool clean) {
    const bool wide_window=beta-alpha>1;
    tick(); auto moves=b.legal_moves(); bool check=b.in_check();
    if(moves.empty()) return check?-MateScore+ply:0;
    if(!synthetic && b.automatic_draw()) return 0;
    bool claim=!synthetic && b.can_claim_draw(true);
    int raw=static_evaluation(b); int stand=!synthetic && !clean?corrected_eval(b,raw,ply):raw;
    trace_[ply].static_eval=check?Infinity:stand;
    if(ply>=MaxPly-1 || qply>=20) return claim?std::max(0,stand):stand;
    if(claim) { if(beta<=0) return 0; alpha=std::max(alpha,0); }
    if(!check) { if(stand>=beta) return stand; alpha=std::max(alpha,stand); }
    const bool safety=limits_.features.search_safety;
    const bool improving=safety && !check && ply>=2 && trace_[ply-2].static_eval!=Infinity && stand>trace_[ply-2].static_eval;
    // Keep terminal detection above, but never sort quiet moves that qsearch
    // cannot visit. Filtering preserves the relative order of retained moves.
    if(!check) moves.erase(std::remove_if(moves.begin(),moves.end(),[&](Move m) {
        return !b.capture(m) && !m.promotion && !(qply<3 && b.gives_check(m));
    }),moves.end());
    order(b,moves,{},ply);
    for(auto m:moves) {
        bool cap=b.capture(m), checking=b.gives_check(m);
        if(!check && !cap && !m.promotion && !(checking && qply<3)) continue;
        bool protected_capture=safety && cap && (wide_window || improving || history_score(b,m,ply)>2000 ||
            (b.attacked(m.from,-b.side) && !b.attacked(m.from,b.side)));
        if(limits_.selective && !clean && !check && cap && !checking && !m.promotion && !protected_capture) {
            if(stand+piece_value(b.squares[m.to])+250<alpha && std::abs(b.squares[m.from])!=Pawn) continue;
            if(see(b,m)<0) continue;
        }
        trace_[ply].move=m; trace_[ply].piece=b.squares[m.from];
        Applied applied(b,m); int score=-quiescence(b,-beta,-alpha,ply+1,qply+1,synthetic,clean);
        if(score>=beta) return score; alpha=std::max(alpha,score);
    } return alpha;
}
int Search::negamax(Board& b,int depth,int alpha,int beta,int ply,bool pv,bool null_allowed,std::vector<Move>& line,bool synthetic,Move excluded,bool auxiliary,int extensions,bool cut_node) {
    line.clear();
    if(depth<=0) return quiescence(b,alpha,beta,ply,0,synthetic,auxiliary);
    tick(); auto moves=b.legal_moves(); bool check=b.in_check();
    if(moves.empty()) return check?-MateScore+ply:0;
    if(!synthetic && b.automatic_draw()) return 0;
    bool claim=!synthetic && b.can_claim_draw(true);
    if(ply>=MaxPly-1) { int value=static_evaluation(b); return claim?std::max(0,value):value; }
    const auto& f=limits_.features;
    if(f.mate_distance) {
        alpha=std::max(alpha,-MateScore+ply);
        beta=std::min(beta,MateScore-ply-1);
        if(alpha>=beta) { ++stats_.mate_distance_cutoffs; return alpha; }
    }
    int original_alpha=alpha;
    if(claim) { if(beta<=0) return 0; alpha=std::max(alpha,0); }
    const bool trusted_context=!synthetic && !auxiliary && !excluded;
    const bool pruning=trusted_context && limits_.selective;
    auto key=b.hash(); auto context=b.proof_key();
    auto entry=trusted_context?tt_->probe(key,context):std::optional<TTEntry>{};
    Move ttmove;
    if(entry) {
        ++stats_.tt_hits; ttmove=entry->move;
        int value=from_tt(entry->score,ply);
        if(!pv && entry->depth>=depth && (entry->bound==Bound::Exact || (entry->bound==Bound::Lower && value>=beta) || (entry->bound==Bound::Upper && value<=alpha))) return value;
    }
    int raw=static_evaluation(b);
    int static_eval=trusted_context?corrected_eval(b,raw,ply):raw;
    trace_[ply].static_eval=check?Infinity:static_eval;
    bool improving=!check && ply>=2 && trace_[ply-2].static_eval!=Infinity && static_eval>trace_[ply-2].static_eval;
    PawnInfo safety_pawns; bool tactical_threat=false;
    if(f.search_safety) {
        safety_pawns=pawn_cache_->probe(b);
        for(int s=0;s<128;++s) if(valid(s) && b.squares[s]==b.side*Queen && b.attacked(s,-b.side)) tactical_threat=true;
    }
    if(pruning && f.iid && !ttmove && depth>=5) {
        ++stats_.iid_searches; std::vector<Move> seed;
        negamax(b,depth-2,alpha,beta,ply,true,false,seed,false,{},true,extensions,false);
        if(!seed.empty()) ttmove=seed.front();
    }
    int singular_extension=0;
    if(pruning && f.singular && !check && entry && ttmove && entry->move==ttmove && depth>=6 && entry->depth>=depth-2 && entry->bound!=Bound::Upper && std::abs(entry->score)<MateThreshold && extensions<2) {
        ++stats_.singular_tests; int threshold=from_tt(entry->score,ply)-2*depth;
        std::vector<Move> ignored;
        int alternative=negamax(b,(depth-1)/2,threshold-1,threshold,ply,false,false,ignored,false,ttmove,true,extensions,false);
        if(alternative<threshold) { singular_extension=1; ++stats_.singular_extensions; }
    }
    if(pruning && null_allowed && !pv && !check && !(f.search_safety && (improving || tactical_threat)) && depth>=3 && null_material(b) && std::abs(beta)<MateThreshold && (!(f.verified_null || f.correction) || static_eval>=beta)) {
        ++stats_.null_attempts; int reduced=std::max(0,depth-1-(2+depth/5)),score;
        trace_[ply].move={}; trace_[ply].piece=0;
        { Applied applied(b,{}); std::vector<Move> ignored;
            score=-negamax(b,reduced,-beta,-beta+1,ply+1,false,false,ignored,true,{},true,extensions,!cut_node); }
        if(score>=beta) {
            bool accept=true;
            if(f.verified_null && depth>=6) {
                ++stats_.null_verifications; std::vector<Move> ignored;
                int verified=negamax(b,reduced,beta-1,beta,ply,false,false,ignored,false,{},true,extensions,cut_node);
                accept=verified>=beta; if(!accept) ++stats_.null_rejections;
            }
            if(accept) return std::min(score,MateThreshold-1);
        }
    }
    order(b,moves,ttmove,ply);
    if(pruning && f.probcut && !pv && !check && !(f.search_safety && (improving || tactical_threat)) && depth>=5 && std::abs(beta)<MateThreshold-256 && static_eval>=beta-150) {
        int raised=beta+140+(improving?40:0);
        for(auto m:moves) if(b.capture(m) && !m.promotion && see(b,m)>=0) {
            ++stats_.probcut_attempts; int score;
            trace_[ply].move=m; trace_[ply].piece=b.squares[m.from];
            { Applied applied(b,m); score=-quiescence(b,-raised,-raised+1,ply+1,0,false,true);
                if(score>=raised) { std::vector<Move> ignored; score=-negamax(b,depth-4,-raised,-raised+1,ply+1,false,false,ignored,false,{},true,extensions,true); }
            }
            if(score>=raised && std::abs(score)<MateThreshold) { ++stats_.probcut_cutoffs; return score-140; }
        }
    }
    trace_[ply].static_eval=check?Infinity:static_eval;
    int best=claim?0:-Infinity,index=0; Move bestmove;
    std::vector<Move> quiets,captures;
    auto update_move=[&](Move m,int bonus) {
        if(!trusted_context) return;
        if(b.capture(m)) {
            if(f.capture_history) { feedback_->update_capture(b.squares[m.from],m.to,b.squares[m.to]?std::abs(b.squares[m.to]):Pawn,bonus); ++stats_.capture_updates; }
        } else {
            auto& h=history_[b.side==White?0:1][m.from][m.to];
            h=std::clamp(h+bonus-h*std::abs(bonus)/16000,-16000,16000);
            if(f.continuation) { int current=Feedback::token(b.squares[m.from],m.to),i=0;
                for(int distance:{1,2,4,6}) { int previous=previous_token(ply,distance); feedback_->update_continuation(previous,current,i++,bonus); if(previous) ++stats_.continuation_updates; }
            }
        }
    };
    for(auto m:moves) {
        if(m==excluded) continue;
        bool cap=b.capture(m),quiet=!cap && !m.promotion && !b.gives_check(m);
        bool killer=m==killers_[ply][0] || m==killers_[ply][1];
        int hist=history_score(b,m,ply),extension=m==ttmove?singular_extension:0;
        SafetySignals signals{pv,m==ttmove,check || b.gives_check(m),bool(m.promotion),hist>2000,bool(extension),false,improving,tactical_threat};
        if(f.search_safety && index>=3) {
            signals.strategic=strategic_candidate(b,m,safety_pawns);
            signals.threat|=b.attacked(m.from,-b.side) && !b.attacked(m.from,b.side);
        }
        bool protected_move=f.search_safety && signals.protect();
        if(protected_move && index>=3) ++stats_.safety_protected;
        bool can_skip=pruning && !protected_move && !pv && !check && !extension && m!=ttmove && !killer && !m.promotion && !signals.check && index>=3 && best>-MateThreshold;
        if(can_skip && f.history_pruning && quiet && depth<=3 && hist<-1000*depth && !improving) { ++stats_.history_prunes; continue; }
        if(can_skip && f.see_pruning && depth<=3 && see(b,m)<-(cap?90:40)*depth*depth) { ++stats_.see_prunes; continue; }
        int reduction=0;
        if(pruning && !protected_move && !check && quiet && m!=ttmove && !killer && !extension && depth>=3 && index>=3 && (!pv || f.dynamic_lmr)) {
            reduction=1+static_cast<int>(std::log(double(depth))*std::log(double(index+1))/3)-(hist>2000);
            if(f.dynamic_lmr) reduction+=(cut_node?1:0)+(hist<-1500?1:0)-(improving?1:0)-(pv?1:0)-(entry && entry->pv?1:0)-(hist>6000?1:0);
            reduction=std::clamp(reduction,0,depth-2); if(reduction) ++stats_.lmr_reductions;
        }
        std::vector<Move> child; int score,child_depth=depth-1+extension;
        trace_[ply].move=m; trace_[ply].piece=b.squares[m.from];
        { Applied applied(b,m);
            if(index==0) score=-negamax(b,child_depth,-beta,-alpha,ply+1,pv,true,child,synthetic,{},auxiliary,extensions+extension,!cut_node);
            else {
                score=-negamax(b,child_depth-reduction,-alpha-1,-alpha,ply+1,false,true,child,synthetic,{},auxiliary,extensions+extension,true);
                if(reduction && score>alpha) { ++stats_.lmr_researches; score=-negamax(b,child_depth,-alpha-1,-alpha,ply+1,false,true,child,synthetic,{},auxiliary,extensions+extension,true); }
                if(score>alpha && score<beta) score=-negamax(b,child_depth,-beta,-alpha,ply+1,pv,true,child,synthetic,{},auxiliary,extensions+extension,false);
            }
        }
        ++index;
        if(score>best) { best=score; bestmove=m; line=child; line.insert(line.begin(),m); }
        alpha=std::max(alpha,score);
        if(alpha>=beta) {
            int bonus=std::min(1500,16*depth*depth); update_move(m,bonus);
            for(auto failed:quiets) update_move(failed,-bonus/2);
            for(auto failed:captures) update_move(failed,-bonus/2);
            if(quiet && trusted_context) { killers_[ply][1]=killers_[ply][0]; killers_[ply][0]=m;
                if(f.countermove) feedback_->set_counter(previous_token(ply),m); }
            break;
        }
        if(cap) captures.push_back(m); else if(quiet) quiets.push_back(m);
    }
    Bound bound=best<=original_alpha?Bound::Upper:best>=beta?Bound::Lower:Bound::Exact;
    if(trusted_context) {
        tt_->store({key,std::move(context),depth,to_tt(best,ply),bound,bestmove,pv},f.tt_policy);
        if(f.correction && !check && !claim && bestmove && !b.capture(bestmove) && !bestmove.promotion && std::abs(best)<MateThreshold &&
           (bound==Bound::Exact || (bound==Bound::Lower && best>static_eval) || (bound==Bound::Upper && best<static_eval))) {
            feedback_->update_correction(b,previous_token(ply),best-raw,depth); ++stats_.correction_updates;
        }
    }
    return best;
}
std::vector<MoveResult> Search::root(Board& b,int depth,int alpha,int beta,bool independent) {
    auto moves=b.legal_moves(); auto entry=tt_->probe(b.hash(),b.proof_key());
    order(b,moves,entry?entry->move:Move{},0);
    std::vector<MoveResult> results; int index=0;
    for(auto m:moves) {
        auto before=nodes_; int a=alpha; std::vector<Move> child; int score;
        trace_[0].move=m; trace_[0].piece=b.squares[m.from];
        trace_[0].static_eval=b.in_check()?Infinity:corrected_eval(b,static_evaluation(b),0);
        { Applied applied(b,m);
            if(index==0 || independent) score=-negamax(b,depth-1,-beta,-alpha,1,true,true,child);
            else { score=-negamax(b,depth-1,-alpha-1,-alpha,1,false,true,child);
                if(score>alpha && score<beta) score=-negamax(b,depth-1,-beta,-alpha,1,true,true,child); }
        }
        MoveResult result; result.move=m; result.score=score; result.depth=depth; result.status=Status::SearchResult;
        result.bound=score<=a?Bound::Upper:score>=beta?Bound::Lower:Bound::Exact; result.nodes=nodes_-before;
        result.pv=child; result.pv.insert(result.pv.begin(),m); results.push_back(result);
        if(!independent) alpha=std::max(alpha,score); ++index;
        if(alpha>=beta) break;
    }
    std::stable_sort(results.begin(),results.end(),[](const auto& a,const auto& c){return a.score>c.score;});
    return results;
}
SearchResult Search::run(Board b,Limits limits,std::atomic_bool& stop,const std::function<void(const SearchResult&)>& info) {
    std::string policy=limits.features.names()+(limits.selective?"|selective":"|full");
    if(policy!=previous_policy_) { clear(); previous_policy_=policy; }
    tt_->new_search();
    std::atomic_bool done=false; std::atomic<std::uint64_t> total=0;
    local_stop_=&done; shared_nodes_=&total; worker_id_=0;
    try { auto result=run_single(std::move(b),limits,stop,info); local_stop_=nullptr; shared_nodes_=nullptr; return result; }
    catch(...) { local_stop_=nullptr; shared_nodes_=nullptr; throw; }
}
SearchResult Search::run_single(Board b,Limits limits,std::atomic_bool& stop,const std::function<void(const SearchResult&)>& info) {
    limits_=limits; limits_.depth=std::clamp(limits.depth,1,MaxPly-2); stop_=&stop; nodes_=0;
    stats_=SearchStats{}; trace_.fill(SearchTrace{}); pawn_cache_->hits=pawn_cache_->misses=0;
    start_=std::chrono::steady_clock::now(); deadline_=limits.milliseconds>0?start_+std::chrono::milliseconds(limits.milliseconds):std::chrono::steady_clock::time_point::max();
    SearchResult result; evaluate_score(b,limits.features.strategic_eval,limits.features.king_safety,limits.features.pawn_cache?pawn_cache_.get():nullptr,&result.evaluation); result.features=limits.features.names();
    std::vector<std::unique_ptr<Search>> helpers;
    std::vector<std::jthread> workers;
    std::vector<std::exception_ptr> failures(std::clamp(limits.threads,1,16));
    auto stop_workers=[&]() { if(worker_id_==0) { local_stop_->store(true); for(auto& worker:workers) if(worker.joinable()) worker.join(); } };
    struct JoinGuard { std::function<void()> fn; ~JoinGuard(){fn();} } join_guard{stop_workers};
    auto finish=[&]() {
        stop_workers();
        for(auto failure:failures) if(failure) std::rethrow_exception(failure);
        result.nodes=worker_id_==0?shared_nodes_->load():nodes_;
        result.stats=stats_; result.stats.threads=1+static_cast<int>(helpers.size());
        result.stats.pawn_cache_hits=pawn_cache_->hits; result.stats.pawn_cache_misses=pawn_cache_->misses;
        result.stats.root_correction=limits.features.correction?feedback_->correction(b,0):0;
        // Aggregate event counts after joining; feedback tables remain private.
        for(const auto& helper:helpers) {
#define AXIOM_SUM(field) result.stats.field += helper->stats_.field
            AXIOM_SUM(correction_updates); AXIOM_SUM(continuation_updates); AXIOM_SUM(capture_updates);
            AXIOM_SUM(tt_hits); AXIOM_SUM(null_attempts); AXIOM_SUM(null_verifications); AXIOM_SUM(null_rejections);
            AXIOM_SUM(singular_tests); AXIOM_SUM(singular_extensions); AXIOM_SUM(probcut_attempts); AXIOM_SUM(probcut_cutoffs);
            AXIOM_SUM(lmr_reductions); AXIOM_SUM(lmr_researches); AXIOM_SUM(history_prunes); AXIOM_SUM(see_prunes);
            AXIOM_SUM(mate_distance_cutoffs); AXIOM_SUM(iid_searches);
            AXIOM_SUM(safety_protected);
            result.stats.pawn_cache_hits+=helper->pawn_cache_->hits; result.stats.pawn_cache_misses+=helper->pawn_cache_->misses;
#undef AXIOM_SUM
        }
        result.elapsed_ms=std::chrono::duration_cast<std::chrono::milliseconds>(std::chrono::steady_clock::now()-start_).count(); return result;
    };
    auto legal=b.legal_moves();
    if(legal.empty()) { result.status=b.in_check()?Status::ProvenMate:Status::ProvenForcedResult; result.outcome=b.in_check()?"LOSS":"DRAW"; result.score=b.in_check()?-MateScore:0; return finish(); }
    if(b.automatic_draw()) { result.status=Status::ProvenForcedResult; result.outcome="DRAW"; result.score=0; return finish(); }
    bool claim=b.can_claim_draw(true);
    for(auto m:legal) { Applied applied(b,m); MoveResult r; r.move=m; r.score=-static_evaluation(b); r.pv={m}; result.moves.push_back(r); }
    std::stable_sort(result.moves.begin(),result.moves.end(),[](const auto& a,const auto& c){return a.score>c.score;});
    result.best=result.moves.front().move; result.score=result.moves.front().score;
    result.tablebase=tablebase.probe(b);
    if(result.tablebase && result.tablebase->exact) {
        result.best=result.tablebase->best; result.status=Status::ExactTablebase;
        int w=result.tablebase->wdl; result.outcome=w==2?"WIN":w==-2?"LOSS":"DRAW"; result.score=w==2?28000:w==-2?-28000:0;
        for(auto& r:result.moves) if(r.move==result.best) { r.status=Status::ExactTablebase; r.score=result.score; r.tablebase=result.tablebase; r.bound=Bound::Exact; }
        return finish();
    }
    if(limits.proof_nodes && limits.mate_plies>=1) {
        auto proof_deadline=limits.milliseconds>0?std::min(deadline_,start_+std::chrono::milliseconds(std::max(1,limits.milliseconds/5))):deadline_;
        auto budget=limits.nodes?std::min(limits.proof_nodes,limits.nodes/4):limits.proof_nodes;
        MateSolver solver; auto proof=solver.solve(b,b.side,limits.mate_plies,budget,&stop,proof_deadline);
        nodes_+=proof.nodes; shared_nodes_->fetch_add(proof.nodes); result.proof_nodes=proof.nodes;
        if(proof.proven && MateSolver::verify(b,b.side,proof.certificate)) {
            result.status=Status::ProvenMate; result.outcome="WIN"; result.certificate_verified=true;
            result.best=proof.certificate->edges.front().first; result.score=MateScore-proof.distance;
            for(auto& r:result.moves) if(r.move==result.best) { r.status=Status::ProvenMate; r.mate_distance=proof.distance; r.score=result.score; r.nodes=proof.nodes; r.bound=Bound::Lower;
                r.pv.clear(); auto node=proof.certificate;
                while(!node->edges.empty()) { auto edge=std::max_element(node->edges.begin(),node->edges.end(),[](const auto& a,const auto& c){return a.second->distance<c.second->distance;}); r.pv.push_back(edge->first); node=edge->second; }
            }
            result.verification_completed=true; result.verification_detail="Exhaustive defender coverage; certificate independently replayed"; return finish();
        }
    }
    if(worker_id_==0 && limits.threads>1 && !stop.load()) {
        for(int id=1;id<std::clamp(limits.threads,1,16);++id) {
            auto helper=std::make_unique<Search>(1); helper->tt_=tt_; helper->worker_id_=id;
            helper->local_stop_=local_stop_; helper->shared_nodes_=shared_nodes_;
            Search* ptr=helper.get(); helpers.push_back(std::move(helper));
            Limits worker_limits=limits; worker_limits.threads=1; worker_limits.proof_nodes=0; worker_limits.verify=false; worker_limits.diagnostics=false;
            worker_limits.soft_milliseconds=0; worker_limits.depth=std::min(MaxPly-2,limits.depth+id%2);
            workers.emplace_back([&,ptr,id,copy=b,worker_limits]() mutable {
                try { ptr->run_single(std::move(copy),worker_limits,stop,{}); }
                catch(...) { failures[id]=std::current_exception(); local_stop_->store(true); }
            });
        }
    }
    int stable_iterations=0; Move previous_best;
    try {
        for(int depth=1;depth<=limits_.depth;++depth) {
            int window=depth>=3 && std::abs(result.score)<MateThreshold?35+worker_id_*7:Infinity;
            std::vector<MoveResult> completed;
            for(;;) {
                int alpha=std::max(-Infinity,result.score-window),beta=std::min(Infinity,result.score+window);
                completed=root(b,depth,alpha,beta);
                int score=completed.front().score;
                if((score<=alpha || score>=beta) && window<2*Infinity) { window=std::min(2*Infinity,window*2); continue; }
                break;
            }
            result.moves=std::move(completed); result.best=result.moves.front().move; result.score=result.moves.front().score;
            result.depth=depth; result.status=Status::SearchResult;
            if(result.best==previous_best) ++stable_iterations;
            else { if(previous_best) ++stats_.bestmove_changes; stable_iterations=0; previous_best=result.best; }
            result.claim_draw=claim && result.score<=0; if(result.claim_draw) result.score=0;
            tt_->store({b.hash(),b.proof_key(),depth,to_tt(result.score,0),Bound::Exact,result.best,true},limits.features.tt_policy);
            result.nodes=shared_nodes_->load(); result.elapsed_ms=std::chrono::duration_cast<std::chrono::milliseconds>(std::chrono::steady_clock::now()-start_).count();
            if(info) info(result);
            if(worker_id_==0 && limits.features.time_management && limits.soft_milliseconds>0 && depth>=3) {
                double factor=stable_iterations>=3?0.7:stable_iterations==0?1.5:1.0;
                if(result.elapsed_ms>=limits.soft_milliseconds*factor) break;
            }
        }
        if(limits.verify) {
            // Full-width root rerun with null-move, LMR and SEE/delta pruning
            // disabled. Still a finite search, not a game-theoretic proof.
            stop_workers(); local_stop_->store(false);
            bool strategic=limits_.features.strategic_eval,king_safety=limits_.features.king_safety;
            clear(); limits_.selective=false; limits_.features.all(false);
            limits_.features.strategic_eval=strategic; limits_.features.king_safety=king_safety; limits_.features.pawn_cache=true;
            int d=std::min(result.depth,4);
            previous_policy_="verification";
            auto verified=root(b,d,-Infinity,Infinity,true);
            for(auto& original:result.moves) for(const auto& checked:verified) if(original.move==checked.move) {
                original.tactical_verified=true; original.verification_depth=d; original.verification_score=checked.score;
                if(checked.pv.size()>1) original.strongest_reply=checked.pv[1];
            }
            for(auto& checked:verified) {
                checked.tactical_verified=true; checked.verification_depth=d; checked.verification_score=checked.score;
                if(checked.pv.size()>1) checked.strongest_reply=checked.pv[1];
            }
            result.verification_completed=true;
            result.verification_detail=verified.front().move==result.best?"Candidate agrees with nonselective verification search":"Alternative found by nonselective verification search";
            if(verified.front().move!=result.best) { result.best=verified.front().move; result.score=verified.front().score; result.moves=std::move(verified); result.depth=d; }
        }
    } catch(const Interrupted&) { if(limits.verify && !result.verification_completed) result.verification_detail="Incomplete: time, node limit or stop reached"; }
    if(limits.verify || limits.diagnostics) for(auto& r:result.moves) r.tactics=tactical_labels(b,r.move);
    result.claim_draw=claim && result.score<=0;
    if(result.claim_draw) result.score=0;
    return finish();
}
std::string json(const SearchResult& r,const Board& b) {
    std::ostringstream o; o<<"{\n  \"fen\":"<<escaped(b.fen())<<",\n  \"bestmove\":"<<escaped(r.best.uci())<<",\n  \"result\":"<<escaped(status_name(r.status))<<",\n  \"outcome\":"<<escaped(r.outcome)<<",\n  \"score_cp\":"<<r.score<<",\n  \"depth\":"<<r.depth<<",\n  \"nodes\":"<<r.nodes<<",\n  \"proof_nodes\":"<<r.proof_nodes<<",\n  \"elapsed_ms\":"<<r.elapsed_ms<<",\n  \"claim_draw\":"<<(r.claim_draw?"true":"false")<<",\n  \"verification\":{\"completed\":"<<(r.verification_completed?"true":"false")<<",\"certificate_verified\":"<<(r.certificate_verified?"true":"false")<<",\"detail\":"<<escaped(r.verification_detail)<<"},\n  \"evaluation\":{\"perspective\":\"side_to_move\",\"total\":"<<r.evaluation.total<<",\"phase\":"<<r.evaluation.phase;
    for(const auto& [name,value]:r.evaluation.terms) o<<','<<escaped(name)<<':'<<value; o<<"},\n  \"moves\":[";
    bool first=true;
    for(const auto& m:r.moves) { if(!first) o<<','; first=false;
        o<<"\n    {\"move\":"<<escaped(m.move.uci())<<",\"evaluation\":"<<m.score<<",\"depth\":"<<m.depth<<",\"proven_status\":"<<escaped(status_name(m.status))<<",\"mate_distance\":";
        if(m.mate_distance<0) o<<"null"; else o<<m.mate_distance;
        o<<",\"bound_type\":"<<escaped(bound_name(m.bound))<<",\"nodes\":"<<m.nodes<<",\"principal_variation\":[";
        for(std::size_t i=0;i<m.pv.size();++i) { if(i) o<<','; o<<escaped(m.pv[i].uci()); } o<<"],\"tactical_status\":[";
        for(std::size_t i=0;i<m.tactics.size();++i) { if(i) o<<','; o<<escaped(m.tactics[i]); }
        o<<"],\"tactical_verification\":{\"completed\":"<<(m.tactical_verified?"true":"false")<<",\"depth\":"<<m.verification_depth<<",\"score\":"<<m.verification_score<<",\"strongest_reply\":"<<escaped(m.strongest_reply.uci())<<"},\"tablebase_result\":";
        if(m.tablebase) o<<"{\"wdl\":"<<m.tablebase->wdl<<",\"dtz\":"<<m.tablebase->dtz<<'}'; else o<<"null";
        o<<'}';
    }
    o<<"\n  ],\n  \"tablebase\":";
    if(r.tablebase) o<<"{\"wdl\":"<<r.tablebase->wdl<<",\"dtz\":"<<r.tablebase->dtz<<",\"exact\":"<<(r.tablebase->exact?"true":"false")<<",\"reason\":"<<escaped(r.tablebase->reason)<<'}'; else o<<"null";
    o<<",\n  \"features\":"<<escaped(r.features)<<",\n  \"search_stats\":{\"threads\":"<<r.stats.threads<<",\"root_correction\":"<<r.stats.root_correction;
#define AXIOM_JSON_STAT(field) o<<",\"" #field "\":"<<r.stats.field
    AXIOM_JSON_STAT(correction_updates); AXIOM_JSON_STAT(continuation_updates); AXIOM_JSON_STAT(capture_updates);
    AXIOM_JSON_STAT(tt_hits); AXIOM_JSON_STAT(null_attempts); AXIOM_JSON_STAT(null_verifications); AXIOM_JSON_STAT(null_rejections);
    AXIOM_JSON_STAT(singular_tests); AXIOM_JSON_STAT(singular_extensions); AXIOM_JSON_STAT(probcut_attempts); AXIOM_JSON_STAT(probcut_cutoffs);
    AXIOM_JSON_STAT(lmr_reductions); AXIOM_JSON_STAT(lmr_researches); AXIOM_JSON_STAT(history_prunes); AXIOM_JSON_STAT(see_prunes);
    AXIOM_JSON_STAT(mate_distance_cutoffs); AXIOM_JSON_STAT(iid_searches); AXIOM_JSON_STAT(bestmove_changes);
    AXIOM_JSON_STAT(safety_protected); AXIOM_JSON_STAT(pawn_cache_hits); AXIOM_JSON_STAT(pawn_cache_misses);
#undef AXIOM_JSON_STAT
    o<<"}\n}\n"; return o.str();
}
}
